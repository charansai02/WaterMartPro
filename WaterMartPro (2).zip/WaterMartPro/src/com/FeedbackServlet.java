package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDAOImpl;

/**
 * Servlet implementation class FeedbackServlet
 */
public class FeedbackServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FeedbackServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String fb = request.getParameter("feedback");
		System.out.println(fb);
		String uname = request.getParameter("uname");
		System.out.println(uname);
		PrintWriter out = response.getWriter();
		boolean fed = new UserDAOImpl().feedback(uname, fb);
		if (!fed) {
			out.write("<html>");
			out.write("<head><link href='Styles.css' rel='Stylesheet'>");
			out.write("<style> body {background-image: url('img/Capture.PNG');background-repeat: no-repeat;  background-color: #cccccc;}h1{margin-left:700px;}</style>");
			out.write("<body><h1>Thank you for your Valuable Feedback!</h1>");
			out.write("</body></html>");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

}
