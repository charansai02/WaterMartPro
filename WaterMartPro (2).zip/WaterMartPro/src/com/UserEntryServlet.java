package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.UserBean;
import dao.MyDBConnection;
import dao.UserDAOImpl;

/**
 * Servlet implementation class UserEntryServlet
 */
public class UserEntryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserEntryServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		UserBean ub = new UserBean();
		ub.setName(request.getParameter("name"));
		ub.setAddress(request.getParameter("address"));
		ub.setUsername(request.getParameter("username"));
		ub.setPassword(request.getParameter("password"));
		ub.setState(request.getParameter("state"));
		ub.setGender(request.getParameter("sex"));
		System.out.println(ub);
		ResultSet rs;
		boolean res = false;
		try {
			Statement s = MyDBConnection.getConnection().createStatement();
			rs = s.executeQuery("select * from users where username='" + ub.getUsername() + "'");
			if (ub.getName() != "" && ub.getAddress() != "" && !rs.next() && ub.getPassword().length() >= 8
					&& ub.getState() != "Default" && ub.getGender() != "")
				
				
				res = new UserDAOImpl().insertUser(ub);
			
			
			if (res) {
				System.out.println("User record inserted");
				RequestDispatcher rd = request.getRequestDispatcher("initialize.html");
				rd.forward(request, response);
			} else {
				PrintWriter out = response.getWriter();
				out.write("User record not inserted.. Try by entering some different usernames.");
				RequestDispatcher rd = request.getRequestDispatcher("registration.html");
				rd.include(request, response);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
