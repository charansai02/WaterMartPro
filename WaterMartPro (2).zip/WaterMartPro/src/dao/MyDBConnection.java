package dao;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class MyDBConnection {
	static String driver, connURL, uname, pwd;
	static Connection con;
	static Properties dbProp;

	public static Connection getConnection() {
		FileReader fr;
		try {
			fr = new FileReader("C:\\Users\\polaku.charansai\\workspace\\StudentEntrySystem\\MyDB.properties");
			dbProp = new Properties();
			dbProp.load(fr);
			driver = dbProp.getProperty("dbOracleDriver");
			connURL = dbProp.getProperty("dbOracleConnURL");
			uname = dbProp.getProperty("dbOracleUsername");
			pwd = dbProp.getProperty("dbOraclePassword");

			Class.forName(driver);
			System.out.println("Driver loaded successfully..");
			con = DriverManager.getConnection(connURL, uname, pwd); // Connection
																	// Interface
			System.out.println("Connection established..");
			return con;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
