function formValidation()
{

	var name = document.registration.name;

	var ucountry = document.registration.state;

	var pwd=document.registration.password
	
	var uname= document.registration.username;
	
	if(allLetter(name))
	{

		if(countryselect(ucountry))
		{
			alert('Form Submitted Successfully')
				
		} 
	}
	else
	{
		alert("Form not submitted!");
	}
	return false;

} 
function allLetter(uname)
{ 
	var letters = /^[A-Za-z]+$/;
	if(uname.value.match(letters))
	{
		return true;
	}
	else
	{
		alert('Username must have alphabet characters only');
		uname.focus();
		return false;
	}
}
function countryselect(ucountry)
{
	if(ucountry.value == "Default")
	{
		alert('Select your country from the list');
		ucountry.focus();
		return false;
	}
	else
	{
		return true;
	}
}
